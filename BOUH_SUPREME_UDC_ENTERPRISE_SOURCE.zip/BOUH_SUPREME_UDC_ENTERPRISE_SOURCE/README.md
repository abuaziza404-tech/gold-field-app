# BOUH SUPREME UDC ENTERPRISE — Flutter Source

هذا الحزمـة هي **المصدر البرمجي** لمنصة استكشاف منجمي ذكية تعمل بدون إنترنت باللغة العربية.

## ما الذي تحتويه
- محرك تقييم جيولوجي محلي
- تحليل 500 متر حول GPS
- تصنيف الأهداف إلى Target-A / Target-B / Target-C
- طبقات خرائط متعددة قابلة للتبديل
- دفتر حقل رقمي
- مساعد محلي قائم على القواعد
- تصدير KML / GeoJSON / CSV / تقرير نصي جاهز للتحويل إلى PDF
- بيانات GIS، KML، KMZ، GeoJSON، GPKG، وصور المشاهد

## ما الذي يجب إضافته يدوياً لاحقاً
ضع ملفاتك الحقيقية داخل:
- `assets/images/layer_natural.png`
- `assets/images/layer_clay.png`
- `assets/images/layer_silica.png`
- `assets/images/layer_radar_fracture.png`
- `assets/images/layer_structural_belts.png`
- `assets/images/layer_contour.png`

وضع المشاهد المسبقة المعالجة والخرائط داخل:
- `assets/maps/`
- `assets/kml/`
- `assets/data/`

## كيف يُبنى المشروع محلياً
1. ثبّت Flutter SDK على جهاز التطوير.
2. داخل مجلد المشروع شغّل:
   ```bash
   flutter pub get
   flutter run
   flutter build apk
   flutter build ios
   ```
3. على iOS استخدم macOS + Xcode + Apple Developer Account للبناء والتوقيع.

## ملاحظة مهمة
هذا المجلد يعطيك **المصدر**. البناء النهائي للـ APK أو IPA يتم محلياً على بيئة Flutter مكتملة.
