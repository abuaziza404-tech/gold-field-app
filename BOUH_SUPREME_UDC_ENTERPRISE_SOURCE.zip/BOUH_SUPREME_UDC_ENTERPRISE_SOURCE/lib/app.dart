import 'package:flutter/material.dart';
import 'src/models/analysis_result.dart';
import 'src/models/field_note.dart';
import 'src/models/geo_envelope.dart';
import 'src/models/geo_target.dart';
import 'src/models/layer_profile.dart';
import 'src/models/spectral_profile.dart';
import 'src/models/structure_node.dart';
import 'src/screens/analyze_screen.dart';
import 'src/screens/assistant_screen.dart';
import 'src/screens/dashboard_screen.dart';
import 'src/screens/export_screen.dart';
import 'src/screens/field_book_screen.dart';
import 'src/screens/layers_screen.dart';
import 'src/screens/map_screen.dart';
import 'src/services/analysis_engine.dart';
import 'src/services/asset_repository.dart';
import 'src/services/assistant_engine.dart';
import 'src/services/report_exporter.dart';
import 'src/services/storage_service.dart';

class BouhEnterpriseApp extends StatefulWidget {
  const BouhEnterpriseApp({super.key});

  @override
  State<BouhEnterpriseApp> createState() => _BouhEnterpriseAppState();
}

class _BouhEnterpriseAppState extends State<BouhEnterpriseApp> {
  final repo = AssetRepository();
  final engine = AnalysisEngine();
  final assistant = AssistantEngine();
  final exporter = ReportExporter();
  final storage = StorageService();

  List<GeoTarget> targets = [];
  List<GeoEnvelope> envelopes = [];
  List<StructureNode> structures = [];
  List<SpectralProfile> spectralProfiles = [];
  List<LayerProfile> layerProfiles = [];
  List<FieldNote> fieldNotes = [];
  AnalysisResult? latestAnalysis;
  bool loading = true;
  int index = 0;
  String activeSceneId = 'regional';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    targets = await repo.loadTargets();
    envelopes = await repo.loadEnvelopes();
    structures = await repo.loadStructures();
    spectralProfiles = await repo.loadSpectralProfiles();
    layerProfiles = await repo.loadSceneProfiles();
    fieldNotes = await storage.loadFieldNotes();
    loading = false;
    if (mounted) setState(() {});
  }

  Future<void> _saveFieldNotes(List<FieldNote> notes) async {
    fieldNotes = notes;
    await storage.saveFieldNotes(notes);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardScreen(targets: targets, envelopes: envelopes, structures: structures, latestAnalysis: latestAnalysis),
      AnalyzeScreen(
        targets: targets,
        structures: structures,
        spectralProfiles: spectralProfiles,
        onAnalysis: (r) => setState(() => latestAnalysis = r),
      ),
      MapScreen(targets: targets, envelopes: envelopes, layerProfiles: layerProfiles, activeSceneId: activeSceneId, onSceneChanged: (v) => setState(() => activeSceneId = v)),
      LayersScreen(layerProfiles: layerProfiles),
      FieldBookScreen(notes: fieldNotes, onChanged: _saveFieldNotes),
      AssistantScreen(assistant: assistant, selectedTarget: targets.isNotEmpty ? targets.first : null, latestAnalysis: latestAnalysis),
      ExportScreen(targets: targets, envelopes: envelopes, structures: structures, notes: fieldNotes, exporter: exporter),
    ];

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BOUH SUPREME UDC',
      locale: const Locale('ar'),
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1976D2), brightness: Brightness.dark),
      ),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('BOUH SUPREME UDC V4.0 — منصة الاستكشاف المؤسسية'),
            actions: [
              if (loading)
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Center(child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))),
                ),
            ],
          ),
          body: pages[index],
          bottomNavigationBar: NavigationBar(
            selectedIndex: index,
            onDestinationSelected: (v) => setState(() => index = v),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'الواجهة'),
              NavigationDestination(icon: Icon(Icons.bolt_outlined), selectedIcon: Icon(Icons.bolt), label: 'تحليل'),
              NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'خرائط'),
              NavigationDestination(icon: Icon(Icons.layers_outlined), selectedIcon: Icon(Icons.layers), label: 'طبقات'),
              NavigationDestination(icon: Icon(Icons.book_outlined), selectedIcon: Icon(Icons.book), label: 'دفتر الحقل'),
              NavigationDestination(icon: Icon(Icons.smart_toy_outlined), selectedIcon: Icon(Icons.smart_toy), label: 'المساعد'),
              NavigationDestination(icon: Icon(Icons.file_download_outlined), selectedIcon: Icon(Icons.file_download), label: 'تصدير'),
            ],
          ),
        ),
      ),
    );
  }
}
