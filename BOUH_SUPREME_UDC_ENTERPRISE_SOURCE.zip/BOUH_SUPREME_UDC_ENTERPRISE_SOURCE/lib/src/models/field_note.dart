class FieldNote {
  final String id;
  final String timestamp;
  final double lat;
  final double lng;
  final String rockType;
  final String veinDirection;
  final String mineralDescription;
  final String photoPath;
  final String comment;
  final String targetId;

  const FieldNote({
    required this.id,
    required this.timestamp,
    required this.lat,
    required this.lng,
    required this.rockType,
    required this.veinDirection,
    required this.mineralDescription,
    required this.photoPath,
    required this.comment,
    required this.targetId,
  });

  factory FieldNote.fromJson(Map<String, dynamic> json) => FieldNote(
        id: json['id'].toString(),
        timestamp: json['timestamp'].toString(),
        lat: (json['lat'] as num).toDouble(),
        lng: (json['lng'] as num).toDouble(),
        rockType: json['rockType'].toString(),
        veinDirection: json['veinDirection'].toString(),
        mineralDescription: json['mineralDescription'].toString(),
        photoPath: json['photoPath'].toString(),
        comment: json['comment'].toString(),
        targetId: json['targetId'].toString(),
      );

  Map<String, dynamic> toJson() => {
    'id': id,
    'timestamp': timestamp,
    'lat': lat,
    'lng': lng,
    'rockType': rockType,
    'veinDirection': veinDirection,
    'mineralDescription': mineralDescription,
    'photoPath': photoPath,
    'comment': comment,
    'targetId': targetId,
  };
}
