class StructureNode {
  final String id;
  final String name;
  final String belt;
  final String kind;
  final double lat;
  final double lng;
  final String strike;
  final double radiusKm;
  final String sourceGroup;
  final String source;
  final String note;

  const StructureNode({
    required this.id,
    required this.name,
    required this.belt,
    required this.kind,
    required this.lat,
    required this.lng,
    required this.strike,
    required this.radiusKm,
    required this.sourceGroup,
    required this.source,
    required this.note,
  });

  factory StructureNode.fromJson(Map<String, dynamic> json) => StructureNode(
        id: json['id'].toString(),
        name: json['name'].toString(),
        belt: json['belt'].toString(),
        kind: json['kind'].toString(),
        lat: (json['lat'] as num).toDouble(),
        lng: (json['lng'] as num).toDouble(),
        strike: json['strike'].toString(),
        radiusKm: (json['radius_km'] as num).toDouble(),
        sourceGroup: json['source_group'].toString(),
        source: json['source'].toString(),
        note: json['note'].toString(),
      );
}
