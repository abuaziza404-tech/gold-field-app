class SpectralProfile {
  final String id;
  final String labelAr;
  final String descriptionAr;
  final Map<String, double> centroid;
  final List<String> bands;
  final List<String> support;

  const SpectralProfile({
    required this.id,
    required this.labelAr,
    required this.descriptionAr,
    required this.centroid,
    required this.bands,
    required this.support,
  });

  factory SpectralProfile.fromJson(Map<String, dynamic> json) => SpectralProfile(
        id: json['id'].toString(),
        labelAr: json['label_ar'].toString(),
        descriptionAr: json['description_ar'].toString(),
        centroid: Map<String, double>.from((json['centroid'] as Map).map((k, v) => MapEntry(k.toString(), (v as num).toDouble()))),
        bands: List<String>.from(json['bands'] as List),
        support: List<String>.from(json['support'] as List),
      );
}
