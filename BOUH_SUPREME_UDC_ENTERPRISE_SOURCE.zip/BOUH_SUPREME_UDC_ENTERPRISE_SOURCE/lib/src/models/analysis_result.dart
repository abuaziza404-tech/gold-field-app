class AnalysisResult {
  final String classification;
  final String status;
  final String type;
  final double confidence;
  final double gpi;
  final double structureScore;
  final double spectralScore;
  final double historicalScore;
  final double subsurfaceScore;
  final double distanceKm;
  final String nearestTargetName;
  final String nearestStructureName;
  final String depthBand;
  final int nearbyTargetCount;
  final String rationale;
  final String recommendation;
  final Map<String, double> indicatorWeights;

  const AnalysisResult({
    required this.classification,
    required this.status,
    required this.type,
    required this.confidence,
    required this.gpi,
    required this.structureScore,
    required this.spectralScore,
    required this.historicalScore,
    required this.subsurfaceScore,
    required this.distanceKm,
    required this.nearestTargetName,
    required this.nearestStructureName,
    required this.depthBand,
    required this.nearbyTargetCount,
    required this.rationale,
    required this.recommendation,
    required this.indicatorWeights,
  });
}
