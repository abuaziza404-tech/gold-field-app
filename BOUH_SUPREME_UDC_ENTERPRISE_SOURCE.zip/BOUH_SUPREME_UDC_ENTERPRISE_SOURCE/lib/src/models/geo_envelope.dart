class GeoEnvelope {
  final String id;
  final String name;
  final String belt;
  final String type;
  final String sourceGroup;
  final String source;
  final String note;
  final List<List<List<double>>> ring;

  const GeoEnvelope({
    required this.id,
    required this.name,
    required this.belt,
    required this.type,
    required this.sourceGroup,
    required this.source,
    required this.note,
    required this.ring,
  });

  factory GeoEnvelope.fromJson(Map<String, dynamic> json) => GeoEnvelope(
        id: json['id'].toString(),
        name: json['name'].toString(),
        belt: json['belt'].toString(),
        type: json['type'].toString(),
        sourceGroup: json['source_group'].toString(),
        source: json['source'].toString(),
        note: json['note'].toString(),
        ring: (json['ring'] as List)
            .map((polygon) => (polygon as List)
                .map((pt) => [
                      (pt[0] as num).toDouble(),
                      (pt[1] as num).toDouble(),
                    ])
                .toList())
            .toList(),
      );
}
