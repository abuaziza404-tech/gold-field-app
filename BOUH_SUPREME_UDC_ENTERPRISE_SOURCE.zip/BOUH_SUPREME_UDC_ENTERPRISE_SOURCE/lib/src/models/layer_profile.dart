class LayerProfile {
  final String id;
  final String label;
  final String asset;
  final String kind;
  final String status;
  final String? notes;

  const LayerProfile({
    required this.id,
    required this.label,
    required this.asset,
    required this.kind,
    required this.status,
    this.notes,
  });

  factory LayerProfile.fromJson(Map<String, dynamic> json) => LayerProfile(
        id: json['id'].toString(),
        label: json['label'].toString(),
        asset: json['asset'].toString(),
        kind: json['kind'].toString(),
        status: json['status'].toString(),
        notes: json['notes']?.toString(),
      );
}
