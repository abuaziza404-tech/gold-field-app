class GeoTarget {
  final String id;
  final String name;
  final String belt;
  final String type;
  final double lat;
  final double lng;
  final String sourceGroup;
  final String source;
  final double score;
  final String label;
  final int evidenceRank;
  final double priority;
  final String note;

  const GeoTarget({
    required this.id,
    required this.name,
    required this.belt,
    required this.type,
    required this.lat,
    required this.lng,
    required this.sourceGroup,
    required this.source,
    required this.score,
    required this.label,
    required this.evidenceRank,
    required this.priority,
    required this.note,
  });

  factory GeoTarget.fromJson(Map<String, dynamic> json) => GeoTarget(
        id: json['id'].toString(),
        name: json['name'].toString(),
        belt: json['belt'].toString(),
        type: json['type'].toString(),
        lat: (json['lat'] as num).toDouble(),
        lng: (json['lng'] as num).toDouble(),
        sourceGroup: json['source_group'].toString(),
        source: json['source'].toString(),
        score: (json['score'] as num).toDouble(),
        label: json['label'].toString(),
        evidenceRank: (json['evidence_rank'] as num).toInt(),
        priority: (json['priority'] as num).toDouble(),
        note: json['note'].toString(),
      );
}
