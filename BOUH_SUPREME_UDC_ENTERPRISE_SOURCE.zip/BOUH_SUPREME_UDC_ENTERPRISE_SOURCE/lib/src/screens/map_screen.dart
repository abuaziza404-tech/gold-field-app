import 'package:flutter/material.dart';
import '../models/geo_envelope.dart';
import '../models/geo_target.dart';
import '../models/layer_profile.dart';
import '../widgets/section_card.dart';

class MapScreen extends StatefulWidget {
  final List<GeoTarget> targets;
  final List<GeoEnvelope> envelopes;
  final List<LayerProfile> layerProfiles;
  final String activeSceneId;
  final ValueChanged<String> onSceneChanged;
  const MapScreen({super.key, required this.targets, required this.envelopes, required this.layerProfiles, required this.activeSceneId, required this.onSceneChanged});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  double overlayOpacity = 0.55;
  String secondarySceneId = 'priority';

  LayerProfile? _layerById(String id) {
    for (final p in widget.layerProfiles) {
      if (p.id == id) return p;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final active = _layerById(widget.activeSceneId);
    final secondary = _layerById(secondarySceneId);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'محرك الخرائط الطبقي',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final p in widget.layerProfiles)
                  ChoiceChip(
                    label: Text(p.label),
                    selected: widget.activeSceneId == p.id,
                    onSelected: (_) => widget.onSceneChanged(p.id),
                  ),
              ]),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: secondarySceneId,
                items: widget.layerProfiles.map((p) => DropdownMenuItem(value: p.id, child: Text('دمج: ${p.label}'))).toList(),
                onChanged: (v) => setState(() => secondarySceneId = v ?? secondarySceneId),
                decoration: const InputDecoration(labelText: 'الطبقة الثانية للشفافية المترابطة'),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: Text('الشفافية: ${(overlayOpacity * 100).round()}%')),
                  Expanded(child: Slider(value: overlayOpacity, onChanged: (v) => setState(() => overlayOpacity = v))),
                ],
              ),
              Text('الطبقة النشطة: ${active?.label ?? 'غير متاح'}'),
              Text('الطبقة المدموجة: ${secondary?.label ?? 'غير متاح'}'),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 520,
          child: SectionCard(
            title: 'مشهد أوفلاين / طبقات + نقاط',
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  _SceneImage(asset: active?.asset ?? 'assets/images/maps_regional_overview.png'),
                  Opacity(
                    opacity: overlayOpacity,
                    child: _SceneImage(asset: secondary?.asset ?? 'assets/images/maps_priority_overview.png'),
                  ),
                  CustomPaint(
                    painter: _OverlayPainter(widget.targets, widget.envelopes),
                    child: const SizedBox.expand(),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        SectionCard(
          title: 'الدعم التشغيلي',
          child: const Text('هذه الواجهة تقرأ المشاهد والخرائط محلياً. استبدل ملفات layer_* placeholder بمشاهدك الفعلية بعد المعالجة: natural, clay, silica, radar fracture, structural belts, contour.'),
        ),
      ],
    );
  }
}

class _SceneImage extends StatelessWidget {
  final String asset;
  const _SceneImage({required this.asset});
  @override
  Widget build(BuildContext context) {
    return Image.asset(
      asset,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: const Color(0xFF0E1726),
        alignment: Alignment.center,
        child: Text(
          'Missing asset\n$asset',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white70),
        ),
      ),
    );
  }
}

class _OverlayPainter extends CustomPainter {
  final List<GeoTarget> targets;
  final List<GeoEnvelope> envelopes;
  _OverlayPainter(this.targets, this.envelopes);

  @override
  void paint(Canvas canvas, Size size) {
    if (targets.isEmpty && envelopes.isEmpty) return;
    final bg = Paint()..color = Colors.transparent;
    canvas.drawRect(Offset.zero & size, bg);

    final allLat = <double>[...targets.map((e) => e.lat), ...envelopes.expand((e) => e.ring.expand((poly) => poly.map((pt) => pt[1])))];
    final allLng = <double>[...targets.map((e) => e.lng), ...envelopes.expand((e) => e.ring.expand((poly) => poly.map((pt) => pt[0])))];
    if (allLat.isEmpty || allLng.isEmpty) return;
    final minLat = allLat.reduce((a, b) => a < b ? a : b);
    final maxLat = allLat.reduce((a, b) => a > b ? a : b);
    final minLng = allLng.reduce((a, b) => a < b ? a : b);
    final maxLng = allLng.reduce((a, b) => a > b ? a : b);
    double xOf(double lng) => ((lng - minLng) / ((maxLng - minLng).abs() + 0.0001)) * (size.width - 20) + 10;
    double yOf(double lat) => ((maxLat - lat) / ((maxLat - minLat).abs() + 0.0001)) * (size.height - 20) + 10;

    final polyPaint = Paint()..color = Colors.cyanAccent.withOpacity(0.18)..style = PaintingStyle.fill;
    final outline = Paint()..color = Colors.cyanAccent.withOpacity(0.60)..style = PaintingStyle.stroke..strokeWidth = 1.4;
    for (final env in envelopes) {
      for (final ring in env.ring) {
        if (ring.isEmpty) continue;
        final path = Path();
        path.moveTo(xOf(ring.first[0]), yOf(ring.first[1]));
        for (final pt in ring.skip(1)) {
          path.lineTo(xOf(pt[0]), yOf(pt[1]));
        }
        path.close();
        canvas.drawPath(path, polyPaint);
        canvas.drawPath(path, outline);
      }
    }
    for (final t in targets) {
      final x = xOf(t.lng);
      final y = yOf(t.lat);
      final c = t.score >= 0.82 ? Colors.redAccent : t.score >= 0.68 ? Colors.orangeAccent : t.score >= 0.55 ? Colors.amber : Colors.lightGreenAccent;
      final p = Paint()..color = c.withOpacity(0.82);
      canvas.drawCircle(Offset(x, y), 6 + (t.priority / 14).clamp(0, 7), p);
      final txt = TextPainter(
        text: TextSpan(text: t.name, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
        textDirection: TextDirection.rtl,
      )..layout(maxWidth: 120);
      txt.paint(canvas, Offset(x + 8, y - 8));
    }
  }

  @override
  bool shouldRepaint(covariant _OverlayPainter oldDelegate) => oldDelegate.targets != targets || oldDelegate.envelopes != envelopes;
}
