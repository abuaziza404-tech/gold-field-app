import 'package:flutter/material.dart';
import '../models/layer_profile.dart';
import '../widgets/section_card.dart';

class LayersScreen extends StatelessWidget {
  final List<LayerProfile> layerProfiles;
  const LayersScreen({super.key, required this.layerProfiles});

  @override
  Widget build(BuildContext context) {
    final expected = layerProfiles.take(6).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const SectionCard(
          title: 'طبقات العمل الأوفلاين',
          child: Text('المنصة تدعم 6 طبقات تشغيلية: الطبيعية، الطين، السيليكا، الكسور الرادارية، الأحزمة البنيوية، والخريطة الكنتورية. استبدل القوالب بصورك الحقيقية بعد المعالجة.'),
        ),
        const SizedBox(height: 12),
        ...expected.map((p) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: SectionCard(
            title: p.label,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ID: ${p.id}'),
                Text('Asset: ${p.asset}'),
                Text('Kind: ${p.kind}'),
                Text('Status: ${p.status}'),
                if (p.notes != null) Text('Notes: ${p.notes}'),
              ],
            ),
          ),
        )),
      ],
    );
  }
}
