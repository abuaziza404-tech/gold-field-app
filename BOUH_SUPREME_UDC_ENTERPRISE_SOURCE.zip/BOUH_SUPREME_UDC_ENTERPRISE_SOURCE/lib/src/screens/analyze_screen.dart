import 'package:flutter/material.dart';
import '../models/analysis_result.dart';
import '../models/geo_target.dart';
import '../models/spectral_profile.dart';
import '../models/structure_node.dart';
import '../services/analysis_engine.dart';
import '../widgets/metric_tile.dart';
import '../widgets/section_card.dart';
import '../widgets/status_badge.dart';

class AnalyzeScreen extends StatefulWidget {
  final List<GeoTarget> targets;
  final List<StructureNode> structures;
  final List<SpectralProfile> spectralProfiles;
  final void Function(AnalysisResult result)? onAnalysis;
  const AnalyzeScreen({super.key, required this.targets, required this.structures, required this.spectralProfiles, this.onAnalysis});

  @override
  State<AnalyzeScreen> createState() => _AnalyzeScreenState();
}

class _AnalyzeScreenState extends State<AnalyzeScreen> {
  final engine = AnalysisEngine();
  final latCtrl = TextEditingController(text: '19.4200');
  final lngCtrl = TextEditingController(text: '36.5600');
  final radiusCtrl = TextEditingController(text: '500');
  SpectralProfile? selectedProfile;
  bool structure = true, pattern = true, clay = true, silica = false, iron = true, quartz = true, gossan = false, sulfide = false, geophysics = false, node = true, edge = false;
  AnalysisResult? result;
  List<GeoTarget> nearby = [];

  @override
  void initState() {
    super.initState();
    selectedProfile = widget.spectralProfiles.isNotEmpty ? widget.spectralProfiles.first : null;
  }

  @override
  Widget build(BuildContext context) {
    final profile = selectedProfile;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'Analyze Now — مسح نصف قطر 500م',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Expanded(child: TextField(controller: latCtrl, decoration: const InputDecoration(labelText: 'Latitude'))),
                const SizedBox(width: 12),
                Expanded(child: TextField(controller: lngCtrl, decoration: const InputDecoration(labelText: 'Longitude'))),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: TextField(controller: radiusCtrl, decoration: const InputDecoration(labelText: 'Radius (m)'))),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<SpectralProfile>(
                    value: profile,
                    items: widget.spectralProfiles.map((p) => DropdownMenuItem(value: p, child: Text(p.labelAr))).toList(),
                    onChanged: (v) => setState(() => selectedProfile = v),
                    decoration: const InputDecoration(labelText: 'البصمة الطيفية'),
                  ),
                ),
              ]),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                _chip('Structure', structure, (v) => setState(() => structure = v)),
                _chip('Pattern', pattern, (v) => setState(() => pattern = v)),
                _chip('Clay (SWIR)', clay, (v) => setState(() => clay = v)),
                _chip('Silica', silica, (v) => setState(() => silica = v)),
                _chip('Iron', iron, (v) => setState(() => iron = v)),
                _chip('Quartz', quartz, (v) => setState(() => quartz = v)),
                _chip('Gossan', gossan, (v) => setState(() => gossan = v)),
                _chip('Sulfide', sulfide, (v) => setState(() => sulfide = v)),
                _chip('Node', node, (v) => setState(() => node = v)),
                _chip('Edge', edge, (v) => setState(() => edge = v)),
                _chip('Geophysics', geophysics, (v) => setState(() => geophysics = v)),
              ]),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: _run, icon: const Icon(Icons.search), label: const Text('Analyze Now')),
            ],
          ),
        ),
        if (result != null) ...[
          const SizedBox(height: 12),
          SectionCard(
            title: 'النتيجة المختصرة',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(spacing: 8, runSpacing: 8, children: [
                  StatusBadge(text: result!.classification, color: result!.classification == 'Target-A' ? Colors.redAccent : result!.classification == 'Target-B' ? Colors.orangeAccent : result!.classification == 'Target-C' ? Colors.amberAccent : Colors.blueGrey),
                  StatusBadge(text: result!.status, color: Colors.lightGreenAccent),
                  StatusBadge(text: result!.type, color: Colors.cyanAccent),
                ]),
                const SizedBox(height: 12),
                MetricTile(label: 'GPI', value: result!.gpi.toStringAsFixed(2), icon: Icons.score_outlined, color: Colors.pinkAccent),
                const SizedBox(height: 8),
                MetricTile(label: 'الثقة', value: result!.confidence.toStringAsFixed(2), icon: Icons.verified_outlined, color: Colors.lightBlueAccent),
                const SizedBox(height: 8),
                MetricTile(label: 'المسافة لأقرب هدف', value: '${result!.distanceKm.toStringAsFixed(2)} كم', icon: Icons.place_outlined),
                const SizedBox(height: 8),
                MetricTile(label: 'العمق التقديري', value: result!.depthBand, icon: Icons.vertical_align_center_outlined),
                const SizedBox(height: 8),
                MetricTile(label: 'أقرب بنية', value: result!.nearestStructureName, icon: Icons.alt_route_outlined),
                const SizedBox(height: 8),
                Text(result!.rationale),
                const SizedBox(height: 8),
                Text('التوصية: ${result!.recommendation}', style: const TextStyle(fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
        if (nearby.isNotEmpty) ...[
          const SizedBox(height: 12),
          SectionCard(
            title: 'أهداف داخل 500م',
            child: Column(
              children: nearby.map((t) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(t.name),
                subtitle: Text('${t.belt} • ${t.note}'),
                trailing: Text(t.score.toStringAsFixed(3)),
              )).toList(),
            ),
          ),
        ]
      ],
    );
  }

  Widget _chip(String label, bool value, ValueChanged<bool> onChanged) => FilterChip(label: Text(label), selected: value, onSelected: onChanged);

  void _run() {
    final lat = double.tryParse(latCtrl.text) ?? 0;
    final lng = double.tryParse(lngCtrl.text) ?? 0;
    final radius = double.tryParse(radiusCtrl.text) ?? 500;
    final profile = selectedProfile ?? widget.spectralProfiles.first;
    nearby = engine.nearbyTargets(lat: lat, lon: lng, targets: widget.targets, radiusKm: radius / 1000.0);
    result = engine.analyze(
      lat: lat,
      lon: lng,
      targets: widget.targets,
      structures: widget.structures,
      spectralProfile: profile,
      structure: structure,
      pattern: pattern,
      clay: clay,
      silica: silica,
      iron: iron,
      quartz: quartz,
      gossan: gossan,
      sulfide: sulfide,
      geophysics: geophysics,
      node: node,
      edge: edge,
    );
    widget.onAnalysis?.call(result!);
    setState(() {});
  }
}
