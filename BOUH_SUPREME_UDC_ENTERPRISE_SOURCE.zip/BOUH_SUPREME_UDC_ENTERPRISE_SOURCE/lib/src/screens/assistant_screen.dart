import 'package:flutter/material.dart';
import '../models/analysis_result.dart';
import '../models/geo_target.dart';
import '../services/assistant_engine.dart';
import '../widgets/section_card.dart';

class AssistantScreen extends StatefulWidget {
  final AssistantEngine assistant;
  final GeoTarget? selectedTarget;
  final AnalysisResult? latestAnalysis;
  const AssistantScreen({super.key, required this.assistant, required this.selectedTarget, required this.latestAnalysis});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final ctrl = TextEditingController(text: 'حلل هذا الموقع');
  final List<Map<String, String>> log = [];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: SectionCard(
            title: 'المساعد المحلي الذكي',
            child: Column(
              children: [
                TextField(controller: ctrl, minLines: 1, maxLines: 3, decoration: const InputDecoration(labelText: 'أمر عربي / English command')),
                const SizedBox(height: 10),
                FilledButton(onPressed: _send, child: const Text('إرسال')),
              ],
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: log.length,
            itemBuilder: (_, i) {
              final item = log[i];
              final isUser = item['role'] == 'user';
              return Align(
                alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  padding: const EdgeInsets.all(12),
                  constraints: const BoxConstraints(maxWidth: 520),
                  decoration: BoxDecoration(
                    color: isUser ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.secondaryContainer,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(item['text'] ?? '', style: const TextStyle(height: 1.4)),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  void _send() {
    final prompt = ctrl.text.trim();
    if (prompt.isEmpty) return;
    final response = widget.assistant.reply(prompt, selectedTarget: widget.selectedTarget, latestAnalysis: widget.latestAnalysis);
    setState(() {
      log.add({'role': 'user', 'text': prompt});
      log.add({'role': 'assistant', 'text': response});
    });
    ctrl.clear();
  }
}
