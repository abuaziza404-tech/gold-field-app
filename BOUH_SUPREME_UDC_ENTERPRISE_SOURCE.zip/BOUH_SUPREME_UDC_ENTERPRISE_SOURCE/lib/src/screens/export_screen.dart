import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/field_note.dart';
import '../models/geo_envelope.dart';
import '../models/geo_target.dart';
import '../models/structure_node.dart';
import '../services/report_exporter.dart';
import '../widgets/section_card.dart';

class ExportScreen extends StatefulWidget {
  final List<GeoTarget> targets;
  final List<GeoEnvelope> envelopes;
  final List<StructureNode> structures;
  final List<FieldNote> notes;
  final ReportExporter exporter;
  const ExportScreen({super.key, required this.targets, required this.envelopes, required this.structures, required this.notes, required this.exporter});

  @override
  State<ExportScreen> createState() => _ExportScreenState();
}

class _ExportScreenState extends State<ExportScreen> {
  String format = 'KML';
  String output = '';

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'التصدير المؤسسي',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(spacing: 8, children: [
                ChoiceChip(label: const Text('KML'), selected: format == 'KML', onSelected: (_) => setState(() => format = 'KML')),
                ChoiceChip(label: const Text('GeoJSON'), selected: format == 'GeoJSON', onSelected: (_) => setState(() => format = 'GeoJSON')),
                ChoiceChip(label: const Text('CSV'), selected: format == 'CSV', onSelected: (_) => setState(() => format = 'CSV')),
                ChoiceChip(label: const Text('Report'), selected: format == 'Report', onSelected: (_) => setState(() => format = 'Report')),
              ]),
              const SizedBox(height: 12),
              Wrap(spacing: 8, children: [
                FilledButton(onPressed: _generate, child: const Text('توليد')),
                FilledButton.tonal(onPressed: _copy, child: const Text('نسخ')),
              ]),
              const SizedBox(height: 12),
              SelectableText(output.isEmpty ? 'لم يتم توليد أي إخراج بعد.' : output, style: const TextStyle(fontFamily: 'monospace', height: 1.35)),
            ],
          ),
        ),
      ],
    );
  }

  void _generate() {
    setState(() {
      output = switch (format) {
        'KML' => widget.exporter.exportKml(targets: widget.targets, envelopes: widget.envelopes, structures: widget.structures),
        'GeoJSON' => widget.exporter.exportGeoJson(targets: widget.targets, envelopes: widget.envelopes, structures: widget.structures),
        'CSV' => widget.exporter.exportCsv(targets: widget.targets, structures: widget.structures, notes: widget.notes),
        _ => widget.exporter.exportReport(targets: widget.targets, envelopes: widget.envelopes, structures: widget.structures, notes: widget.notes),
      };
    });
  }

  Future<void> _copy() async {
    if (output.isEmpty) _generate();
    await Clipboard.setData(ClipboardData(text: output));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ الإخراج')));
  }
}
