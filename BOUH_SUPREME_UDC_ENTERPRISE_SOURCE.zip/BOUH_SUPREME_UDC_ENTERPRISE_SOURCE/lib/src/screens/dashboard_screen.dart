import 'package:flutter/material.dart';
import '../models/analysis_result.dart';
import '../models/geo_envelope.dart';
import '../models/geo_target.dart';
import '../models/structure_node.dart';
import '../widgets/metric_tile.dart';
import '../widgets/section_card.dart';
import '../widgets/status_badge.dart';
import '../widgets/target_badge.dart';

class DashboardScreen extends StatelessWidget {
  final List<GeoTarget> targets;
  final List<GeoEnvelope> envelopes;
  final List<StructureNode> structures;
  final AnalysisResult? latestAnalysis;
  const DashboardScreen({super.key, required this.targets, required this.envelopes, required this.structures, required this.latestAnalysis});

  @override
  Widget build(BuildContext context) {
    final topTargets = (targets.toList()..sort((a, b) => b.priority.compareTo(a.priority))).take(5).toList();
    final topStructure = structures.isNotEmpty ? structures.first : null;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'لوحة القيادة المؤسسية — BOUH SUPREME UDC',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(spacing: 10, runSpacing: 10, children: [
                StatusBadge(text: 'وضع أوفلاين', color: Colors.greenAccent),
                StatusBadge(text: 'العربية كاملة', color: Colors.lightBlueAccent),
                StatusBadge(text: 'GPI + GPS + GIS', color: Colors.orangeAccent),
              ]),
              const SizedBox(height: 14),
              MetricTile(label: 'الأهداف المحمّلة', value: '${targets.length}', icon: Icons.place_outlined),
              const SizedBox(height: 8),
              MetricTile(label: 'الأغلفة البنيوية', value: '${envelopes.length}', icon: Icons.layers_outlined),
              const SizedBox(height: 8),
              MetricTile(label: 'البنى المرجعية', value: '${structures.length}', icon: Icons.alt_route_outlined),
              const SizedBox(height: 8),
              if (latestAnalysis != null) ...[
                MetricTile(label: 'آخر تحليل', value: latestAnalysis!.classification, icon: Icons.analytics_outlined, color: Colors.amberAccent),
                const SizedBox(height: 8),
                MetricTile(label: 'GPI', value: latestAnalysis!.gpi.toStringAsFixed(2), icon: Icons.score_outlined, color: Colors.pinkAccent),
              ],
              const SizedBox(height: 12),
              if (topStructure != null)
                Text('أقرب هيكل مرجعي: ${topStructure.name} — ${topStructure.kind} — ${topStructure.strike}'),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SectionCard(
          title: 'أعلى الأهداف حالياً',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ...topTargets.map((t) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(children: [TargetBadge(text: t.name, color: Colors.greenAccent), const SizedBox(width: 10), Expanded(child: Text('${t.belt} • ${t.note}')), Text(t.score.toStringAsFixed(3))]),
              )),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SectionCard(
          title: 'قواعد المحرك',
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('1) Structure + Pattern = شرط دخول'),
              Text('2) Clay (SWIR) = شرط ترقية'),
              Text('3) Cluster ≥ 3 مؤشرات = تفعيل'),
              Text('4) 500m Scan = تحليل فوري حول GPS'),
              Text('5) Analyze Now = ملخص فني مباشر'),
            ],
          ),
        ),
      ],
    );
  }
}
