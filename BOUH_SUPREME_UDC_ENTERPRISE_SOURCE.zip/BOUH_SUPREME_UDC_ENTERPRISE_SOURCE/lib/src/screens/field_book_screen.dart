import 'package:flutter/material.dart';
import '../models/field_note.dart';
import '../widgets/section_card.dart';

class FieldBookScreen extends StatefulWidget {
  final List<FieldNote> notes;
  final Future<void> Function(List<FieldNote>) onChanged;
  const FieldBookScreen({super.key, required this.notes, required this.onChanged});

  @override
  State<FieldBookScreen> createState() => _FieldBookScreenState();
}

class _FieldBookScreenState extends State<FieldBookScreen> {
  final latCtrl = TextEditingController(text: '19.4200');
  final lngCtrl = TextEditingController(text: '36.5600');
  final rockCtrl = TextEditingController();
  final veinCtrl = TextEditingController();
  final mineralCtrl = TextEditingController();
  final commentCtrl = TextEditingController();
  final targetCtrl = TextEditingController(text: 'tb');

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SectionCard(
          title: 'دفتر الحقل الرقمي',
          child: Column(
            children: [
              Row(children: [Expanded(child: TextField(controller: latCtrl, decoration: const InputDecoration(labelText: 'Latitude'))), const SizedBox(width: 12), Expanded(child: TextField(controller: lngCtrl, decoration: const InputDecoration(labelText: 'Longitude')))]),
              const SizedBox(height: 8),
              TextField(controller: targetCtrl, decoration: const InputDecoration(labelText: 'Target ID')),
              const SizedBox(height: 8),
              TextField(controller: rockCtrl, decoration: const InputDecoration(labelText: 'نوع الصخر')),
              const SizedBox(height: 8),
              TextField(controller: veinCtrl, decoration: const InputDecoration(labelText: 'اتجاه العرق')),
              const SizedBox(height: 8),
              TextField(controller: mineralCtrl, decoration: const InputDecoration(labelText: 'وصف المعدن')),
              const SizedBox(height: 8),
              TextField(controller: commentCtrl, maxLines: 3, decoration: const InputDecoration(labelText: 'ملاحظات ميدانية')),
              const SizedBox(height: 10),
              FilledButton.icon(onPressed: _add, icon: const Icon(Icons.add), label: const Text('إضافة الملاحظة')),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SectionCard(
          title: 'سجل الملاحظات',
          child: Column(
            children: widget.notes.reversed.map((n) => ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('${n.rockType} • ${n.veinDirection}'),
              subtitle: Text('${n.lat}, ${n.lng}\n${n.mineralDescription}\n${n.comment}'),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(n.id)),
            )).toList(),
          ),
        )
      ],
    );
  }

  Future<void> _add() async {
    final note = FieldNote(
      id: 'note-${DateTime.now().millisecondsSinceEpoch}',
      timestamp: DateTime.now().toIso8601String(),
      lat: double.tryParse(latCtrl.text) ?? 0,
      lng: double.tryParse(lngCtrl.text) ?? 0,
      rockType: rockCtrl.text.trim(),
      veinDirection: veinCtrl.text.trim(),
      mineralDescription: mineralCtrl.text.trim(),
      photoPath: '',
      comment: commentCtrl.text.trim(),
      targetId: targetCtrl.text.trim(),
    );
    final next = [...widget.notes, note];
    await widget.onChanged(next);
    rockCtrl.clear(); veinCtrl.clear(); mineralCtrl.clear(); commentCtrl.clear();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الملاحظة')));
  }

  Future<void> _delete(String id) async {
    final next = widget.notes.where((e) => e.id != id).toList();
    await widget.onChanged(next);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حذف الملاحظة')));
  }
}
