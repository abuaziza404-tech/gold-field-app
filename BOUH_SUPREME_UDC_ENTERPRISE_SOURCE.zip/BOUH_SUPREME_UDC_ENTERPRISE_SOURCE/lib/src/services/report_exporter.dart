import 'dart:convert';
import '../models/field_note.dart';
import '../models/geo_envelope.dart';
import '../models/geo_target.dart';
import '../models/structure_node.dart';

class ReportExporter {
  String exportKml({required List<GeoTarget> targets, required List<GeoEnvelope> envelopes, required List<StructureNode> structures}) {
    final b = StringBuffer()
      ..writeln('<?xml version="1.0" encoding="UTF-8"?>')
      ..writeln('<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>BOUH SUPREME UDC</name>');

    for (final t in targets) {
      b.writeln('<Placemark><name>${_xml(t.name)}</name><description>${_xml(t.note)}</description><Point><coordinates>${t.lng},${t.lat},0</coordinates></Point></Placemark>');
    }
    for (final s in structures) {
      b.writeln('<Placemark><name>${_xml(s.name)}</name><description>${_xml(s.note)}</description><Point><coordinates>${s.lng},${s.lat},0</coordinates></Point></Placemark>');
    }
    for (final e in envelopes) {
      final coords = e.ring.isNotEmpty ? e.ring.first.map((p) => '${p[0]},${p[1]},0').join(' ') : '';
      if (coords.isNotEmpty) {
        b.writeln('<Placemark><name>${_xml(e.name)}</name><description>${_xml(e.note)}</description><Polygon><outerBoundaryIs><LinearRing><coordinates>$coords</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>');
      }
    }
    b.writeln('</Document></kml>');
    return b.toString();
  }

  String exportGeoJson({required List<GeoTarget> targets, required List<GeoEnvelope> envelopes, required List<StructureNode> structures}) {
    final features = <Map<String, dynamic>>[];
    for (final t in targets) {
      features.add({
        'type': 'Feature',
        'properties': {
          'kind': 'target',
          'id': t.id,
          'name': t.name,
          'belt': t.belt,
          'score': t.score,
          'label': t.label,
          'priority': t.priority,
          'note': t.note,
        },
        'geometry': {'type': 'Point', 'coordinates': [t.lng, t.lat]},
      });
    }
    for (final s in structures) {
      features.add({
        'type': 'Feature',
        'properties': {
          'kind': 'structure',
          'id': s.id,
          'name': s.name,
          'belt': s.belt,
          'kind_label': s.kind,
          'strike': s.strike,
          'note': s.note,
        },
        'geometry': {'type': 'Point', 'coordinates': [s.lng, s.lat]},
      });
    }
    for (final e in envelopes) {
      features.add({
        'type': 'Feature',
        'properties': {
          'kind': 'envelope',
          'id': e.id,
          'name': e.name,
          'belt': e.belt,
          'note': e.note,
        },
        'geometry': {
          'type': 'Polygon',
          'coordinates': e.ring,
        },
      });
    }
    return jsonEncode({'type': 'FeatureCollection', 'name': 'BOUH_SUPREME_UDC', 'features': features});
  }

  String exportCsv({required List<GeoTarget> targets, required List<StructureNode> structures, required List<FieldNote> notes}) {
    final rows = <String>[
      'kind,id,name,belt,type,lat,lng,value_1,value_2,note',
      ...targets.map((t) => ['target', t.id, t.name, t.belt, t.type, t.lat, t.lng, t.score, t.priority, t.note]),
      ...structures.map((s) => ['structure', s.id, s.name, s.belt, s.kind, s.lat, s.lng, s.radiusKm, s.strike, s.note]),
      ...notes.map((n) => ['field_note', n.id, 'ملاحظة حقل', n.targetId, n.rockType, n.lat, n.lng, n.veinDirection, n.mineralDescription, n.comment]),
    ].map((row) => row.map(_csv).join(',')).toList();
    return rows.join('
');
  }

  String exportReport({required List<GeoTarget> targets, required List<GeoEnvelope> envelopes, required List<StructureNode> structures, required List<FieldNote> notes}) {
    final top = (targets.toList()..sort((a, b) => b.priority.compareTo(a.priority))).take(8).toList();
    final b = StringBuffer()
      ..writeln('# BOUH SUPREME UDC — تقرير هدف مكتشف')
      ..writeln('')
      ..writeln('## ملخص')
      ..writeln('- عدد الأهداف: ${targets.length}')
      ..writeln('- عدد الأحزمة/الأغلفة: ${envelopes.length}')
      ..writeln('- عدد البنى: ${structures.length}')
      ..writeln('- عدد ملاحظات الحقل: ${notes.length}')
      ..writeln('')
      ..writeln('## أعلى الأهداف')
      ..writeln(top.map((t) => '- ${t.name} | ${t.belt} | score=${t.score.toStringAsFixed(3)} | priority=${t.priority.toStringAsFixed(3)}').join('
'))
      ..writeln('')
      ..writeln('## التوصية')
      ..writeln('ابدأ دائمًا بأعلى هدف داخل منطقة تحمل Structure + Pattern + Clay ثم راجع بالميدان.')
      ..writeln('')
      ..writeln('## المرفقات')
      ..writeln('- KML / GeoJSON / CSV يمكن تصديرها من شاشة التصدير داخل التطبيق.');
    return b.toString();
  }

  String _xml(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
  String _csv(Object? value) => '"${value.toString().replaceAll('"', '""')}"';
}
