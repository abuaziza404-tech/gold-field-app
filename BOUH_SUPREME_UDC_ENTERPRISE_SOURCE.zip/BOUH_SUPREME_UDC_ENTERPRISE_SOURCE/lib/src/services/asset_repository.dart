import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models/field_note.dart';
import '../models/geo_envelope.dart';
import '../models/geo_target.dart';
import '../models/layer_profile.dart';
import '../models/spectral_profile.dart';
import '../models/structure_node.dart';

class AssetRepository {
  Future<List<GeoTarget>> loadTargets() async {
    final raw = await rootBundle.loadString('assets/data/targets.json');
    final list = jsonDecode(raw) as List<dynamic>;
    return list.map((e) => GeoTarget.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<List<GeoEnvelope>> loadEnvelopes() async {
    final raw = await rootBundle.loadString('assets/data/envelopes.json');
    final list = jsonDecode(raw) as List<dynamic>;
    return list.map((e) => GeoEnvelope.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<List<StructureNode>> loadStructures() async {
    final raw = await rootBundle.loadString('assets/data/structure_catalog.json');
    final list = jsonDecode(raw) as List<dynamic>;
    return list.map((e) => StructureNode.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<List<SpectralProfile>> loadSpectralProfiles() async {
    final raw = await rootBundle.loadString('assets/data/spectral_library.json');
    final list = jsonDecode(raw) as List<dynamic>;
    return list.map((e) => SpectralProfile.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<List<LayerProfile>> loadSceneProfiles() async {
    final raw = await rootBundle.loadString('assets/data/scene_manifest.json');
    final map = jsonDecode(raw) as Map<String, dynamic>;
    final list = map['scenes'] as List<dynamic>;
    return list.map((e) => LayerProfile.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<String> loadSystemManifest() => rootBundle.loadString('assets/data/system_manifest.json');

  Future<List<FieldNote>> loadSeedNotes() async {
    final raw = await rootBundle.loadString('assets/data/field_notes_seed.json');
    final map = jsonDecode(raw) as Map<String, dynamic>;
    final list = (map['notes'] as List<dynamic>?) ?? [];
    return list.map((e) => FieldNote.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }
}
