import 'dart:math';
import '../models/analysis_result.dart';
import '../models/geo_target.dart';
import '../models/spectral_profile.dart';
import '../models/structure_node.dart';

class AnalysisEngine {
  static const double earthRadiusKm = 6371.0088;

  double haversineKm(double lat1, double lon1, double lat2, double lon2) {
    final dLat = _degToRad(lat2 - lat1);
    final dLon = _degToRad(lon2 - lon1);
    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_degToRad(lat1)) * cos(_degToRad(lat2)) * sin(dLon / 2) * sin(dLon / 2);
    final c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return earthRadiusKm * c;
  }

  double _degToRad(double deg) => deg * pi / 180.0;

  List<GeoTarget> nearbyTargets({required double lat, required double lon, required List<GeoTarget> targets, double radiusKm = 0.5}) {
    return targets.where((t) => haversineKm(lat, lon, t.lat, t.lng) <= radiusKm).toList()
      ..sort((a, b) => haversineKm(lat, lon, a.lat, a.lng).compareTo(haversineKm(lat, lon, b.lat, b.lng)));
  }

  AnalysisResult analyze({
    required double lat,
    required double lon,
    required List<GeoTarget> targets,
    required List<StructureNode> structures,
    required SpectralProfile spectralProfile,
    required bool structure,
    required bool pattern,
    required bool clay,
    required bool silica,
    required bool iron,
    required bool quartz,
    required bool gossan,
    required bool sulfide,
    required bool geophysics,
    required bool node,
    required bool edge,
  }) {
    final nearby = nearbyTargets(lat: lat, lon: lon, targets: targets);
    final nearestTarget = nearby.isEmpty ? targets.first : nearby.first;
    final targetDistanceKm = haversineKm(lat, lon, nearestTarget.lat, nearestTarget.lng);

    final nearestStructureEntry = structures.isEmpty
        ? null
        : structures
            .map((s) => MapEntry(s, haversineKm(lat, lon, s.lat, s.lng)))
            .reduce((a, b) => a.value < b.value ? a : b);
    final nearestStructureName = nearestStructureEntry?.key.name ?? 'غير متاح';
    final nearestStructureDistanceKm = nearestStructureEntry?.value ?? 999.0;

    final structureScore = _clip01(structure ? 0.6 + (nearestStructureDistanceKm <= 0.5 ? 0.4 : max(0, 0.4 - nearestStructureDistanceKm / 10)) : 0.12);
    final patternScore = _clip01(pattern ? 0.72 + (node ? 0.12 : 0.0) + (edge ? 0.06 : 0.0) : 0.18);

    final spectralScore = _spectralScore(
      spectralProfile: spectralProfile,
      clay: clay,
      silica: silica,
      iron: iron,
      quartz: quartz,
      gossan: gossan,
      sulfide: sulfide,
      geophysics: geophysics,
    );

    final historicalScore = _clip01((nearestTarget.priority / 100.0) * 0.65 + nearestTarget.score * 0.35);
    final subsurfaceScore = _clip01((structureScore * 0.45) + (patternScore * 0.25) + (spectralScore * 0.30));
    final gpi = _clip01((structureScore * 0.40) + (spectralScore * 0.40) + (historicalScore * 0.20));
    final confidence = _clip01((gpi * 0.70) + (_clusterConfidence(clay, silica, iron, quartz, gossan, sulfide, node, edge) * 0.30));

    final nearbyCount = nearby.length;
    final indicatorCount = [structure, pattern, clay, silica, iron, quartz, gossan, sulfide, geophysics, node, edge].where((e) => e).length;
    final depthBand = _depthBand(subsurfaceScore);

    String classification;
    String status;
    String type;
    String recommendation;

    if (!structure || !pattern) {
      classification = 'Reject';
      status = 'Reject';
      type = 'R';
      recommendation = 'لا يوجد هيكل أو نمط كافٍ؛ لا يبدأ النزول.';
    } else if (clay && (quartz || silica) && gpi >= 0.82 && nearbyCount >= 1) {
      classification = 'Target-A';
      status = 'GO';
      type = 'GV';
      recommendation = 'هدف سطحي/قريب، ابدأ بالتثبيت والمقطع القصير.';
    } else if ((silica || quartz || iron) && gpi >= 0.68) {
      classification = 'Target-B';
      status = 'CHECK';
      type = 'GM';
      recommendation = 'هدف واعد، يحتاج SWIR أو Zoom أو trench قصير.';
    } else if (subsurfaceScore >= 0.55 && structure && pattern) {
      classification = 'Target-C';
      status = 'TEST';
      type = 'GH';
      recommendation = 'إشارة تحت سطحية؛ أولوية للتحقق الجيوفيزيائي أو trench أعمق.';
    } else if (!clay) {
      classification = 'Hold';
      status = 'HOLD';
      type = 'GM';
      recommendation = 'الطين غير مؤكد؛ الهدف يبقى معلّقاً حتى تأكيد SWIR.';
    } else {
      classification = 'Reject';
      status = 'Reject';
      type = 'R';
      recommendation = 'التركيب لا يكفي؛ استبعده من القائمة.';
    }

    final rationale = [
      'أقرب هدف: ${nearestTarget.name} (${targetDistanceKm.toStringAsFixed(2)} كم)',
      'أقرب بنية: $nearestStructureName (${nearestStructureDistanceKm.toStringAsFixed(2)} كم)',
      'التراكب الطيفي: ${spectralProfile.labelAr}',
      'عدد المؤشرات: $indicatorCount',
      'نقاط قريبة ضمن 500م: $nearbyCount',
    ].join(' | ');

    final indicatorWeights = <String, double>{
      'structure': structureScore,
      'pattern': patternScore,
      'clay': clay ? 1.0 : 0.0,
      'silica': silica ? 0.92 : 0.0,
      'iron': iron ? 0.74 : 0.0,
      'quartz': quartz ? 0.88 : 0.0,
      'gossan': gossan ? 0.91 : 0.0,
      'sulfide': sulfide ? 0.95 : 0.0,
      'node': node ? 0.82 : 0.0,
      'edge': edge ? 0.56 : 0.0,
      'geophysics': geophysics ? 0.85 : 0.0,
    };

    return AnalysisResult(
      classification: classification,
      status: status,
      type: type,
      confidence: confidence,
      gpi: gpi,
      structureScore: structureScore,
      spectralScore: spectralScore,
      historicalScore: historicalScore,
      subsurfaceScore: subsurfaceScore,
      distanceKm: targetDistanceKm,
      nearestTargetName: nearestTarget.name,
      nearestStructureName: nearestStructureName,
      depthBand: depthBand,
      nearbyTargetCount: nearbyCount,
      rationale: rationale,
      recommendation: recommendation,
      indicatorWeights: indicatorWeights,
    );
  }

  double _spectralScore({
    required SpectralProfile spectralProfile,
    required bool clay,
    required bool silica,
    required bool iron,
    required bool quartz,
    required bool gossan,
    required bool sulfide,
    required bool geophysics,
  }) {
    final base = switch (spectralProfile.id) {
      'clay_swir' => 0.38,
      'silica_quartz' => 0.36,
      'iron_oxide' => 0.28,
      'sulfide_mixed' => 0.31,
      _ => 0.20,
    };
    final boost = [
      clay ? 0.26 : 0.0,
      silica ? 0.18 : 0.0,
      iron ? 0.12 : 0.0,
      quartz ? 0.17 : 0.0,
      gossan ? 0.14 : 0.0,
      sulfide ? 0.16 : 0.0,
      geophysics ? 0.08 : 0.0,
    ].fold(0.0, (a, b) => a + b);
    return _clip01(base + boost);
  }

  double _clusterConfidence(bool clay, bool silica, bool iron, bool quartz, bool gossan, bool sulfide, bool node, bool edge) {
    final indicators = [clay, silica, iron, quartz, gossan, sulfide, node, edge].where((e) => e).length;
    if (indicators >= 6) return 0.98;
    if (indicators >= 5) return 0.90;
    if (indicators >= 4) return 0.80;
    if (indicators >= 3) return 0.68;
    if (indicators >= 2) return 0.45;
    return 0.20;
  }

  double _clip01(double v) => v.clamp(0.0, 1.0);

  String _depthBand(double subsurfaceScore) {
    if (subsurfaceScore >= 0.85) return '0–5m';
    if (subsurfaceScore >= 0.70) return '5–20m';
    if (subsurfaceScore >= 0.55) return '20–50m';
    return '>50m';
  }
}
