import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/field_note.dart';

class StorageService {
  static const _notesKey = 'bouh_field_notes_v1';

  Future<List<FieldNote>> loadFieldNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_notesKey);
    if (raw == null || raw.isEmpty) return [];
    final data = jsonDecode(raw) as List<dynamic>;
    return data.map((e) => FieldNote.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<void> saveFieldNotes(List<FieldNote> notes) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_notesKey, jsonEncode(notes.map((e) => e.toJson()).toList()));
  }
}
