import '../models/analysis_result.dart';
import '../models/geo_target.dart';

class AssistantEngine {
  String reply(String prompt, {GeoTarget? selectedTarget, AnalysisResult? latestAnalysis}) {
    final p = prompt.trim().toLowerCase();
    if (p.contains('حلل') || p.contains('analyze')) {
      if (latestAnalysis == null) return 'اختر موقعاً أولاً ثم اضغط Analyze Now.';
      return [
        'النتيجة: ${latestAnalysis.classification}',
        'الحالة: ${latestAnalysis.status}',
        'النوع: ${latestAnalysis.type}',
        'GPI: ${latestAnalysis.gpi.toStringAsFixed(2)}',
        'الثقة: ${latestAnalysis.confidence.toStringAsFixed(2)}',
        'العمق: ${latestAnalysis.depthBand}',
        'أقرب بنية: ${latestAnalysis.nearestStructureName}',
        'أقرب هدف: ${latestAnalysis.nearestTargetName}',
        'المسافة: ${latestAnalysis.distanceKm.toStringAsFixed(2)} كم',
        'ملاحظة: ${latestAnalysis.recommendation}',
      ].join('
');
    }
    if (p.contains('clay') || p.contains('swir') || p.contains('طين')) {
      return 'قاعدة BOUH: Clay (SWIR) هو شرط الترقية. بدون Clay يبقى الهدف HOLD أو يتوقف عند مرحلة التحقق.';
    }
    if (p.contains('structure') || p.contains('shear') || p.contains('بنية')) {
      return 'Structure + Pattern = احتمال، Structure + Pattern + Clay = هدف حقيقي.';
    }
    if (p.contains('gps') || p.contains('مسافة')) {
      return 'الأولوية تكون لأقرب بنية وأقرب تقاطع ضمن 500م مع تراكب طيفي واضح.';
    }
    if (selectedTarget != null) {
      return 'الهدف المختار: ${selectedTarget.name} داخل ${selectedTarget.belt} — ${selectedTarget.note}';
    }
    return 'اكتب: "حلل هذا الموقع" أو اختر هدفاً من القائمة.';
  }
}
