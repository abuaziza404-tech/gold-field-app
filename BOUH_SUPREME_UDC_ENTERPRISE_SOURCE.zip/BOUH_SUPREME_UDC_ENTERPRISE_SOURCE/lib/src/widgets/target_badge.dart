import 'package:flutter/material.dart';

class TargetBadge extends StatelessWidget {
  final String text;
  final Color color;
  const TargetBadge({super.key, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: color.withOpacity(.16), borderRadius: BorderRadius.circular(999), border: Border.all(color: color.withOpacity(.35))),
      child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w800)),
    );
  }
}
