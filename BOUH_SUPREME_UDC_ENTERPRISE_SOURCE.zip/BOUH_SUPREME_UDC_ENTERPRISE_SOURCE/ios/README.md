هذا المشروع Flutter. مجلد iOS الكامل يجب أن يُولَّد عبر:

```bash
flutter create .
```

ثم افتح `ios/Runner.xcworkspace` في Xcode للبناء والتوقيع.
