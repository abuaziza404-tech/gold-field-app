# BOUH SUPREME UDC — Release Guide

1. Commit `codemagic.yaml` to the repository root.
2. In Codemagic, connect the repository and scan for the YAML file.
3. Add the signing credentials group named `bouh_signing` in App settings.
4. Replace `YOUR_EMAIL@example.com` with the receiving email.
5. Trigger `android_release` or `ios_release`.

## Notes
- The workflow first generates missing Flutter platform folders if needed.
- Email publishing sends artifact download links on success.
- For iOS release, upload Apple signing credentials in Codemagic before the signed build.
