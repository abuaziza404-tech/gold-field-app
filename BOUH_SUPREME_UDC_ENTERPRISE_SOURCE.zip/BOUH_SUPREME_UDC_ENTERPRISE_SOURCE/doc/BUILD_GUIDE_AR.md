# دليل البناء المختصر

## Flutter
1. ثبّت Flutter SDK على macOS أو Windows أو Linux.
2. افتح مجلد المشروع.
3. نفّذ:
   ```bash
   flutter pub get
   flutter run
   flutter build apk
   flutter build ios
   ```

## iOS
- للبناء النهائي استخدم macOS + Xcode.
- افتح `ios/Runner.xcworkspace`.
- فعّل signing ثم Build.

## Android
- شغّل `flutter build apk` أو استخدم Android Studio.

## استبدال المشاهد
ضع مشاهدك الحقيقية في:
- `assets/images/layer_natural.png`
- `assets/images/layer_clay.png`
- `assets/images/layer_silica.png`
- `assets/images/layer_radar_fracture.png`
- `assets/images/layer_structural_belts.png`
- `assets/images/layer_contour.png`

ثم حدّث `assets/data/scene_manifest.json` إذا غيّرت أسماء الملفات.
