
let rawTargets = [];
let rawEnvelopes = [];
let selectedId = null;
const groupOrder = ['all','core','review','archive','reference'];
const colorMap = {
  core: '#f59e0b',
  review: '#ef4444',
  archive: '#2563eb',
  reference: '#16a34a',
  derived: '#0ea5e9',
  source: '#64748b'
};

function fmt(n, digits=4){ return Number(n).toFixed(digits); }

async function loadData(){
  const [targets, envelopes] = await Promise.all([
    fetch('data/targets.json').then(r => r.json()),
    fetch('data/envelopes.json').then(r => r.json())
  ]);
  rawTargets = targets;
  rawEnvelopes = envelopes;
  initUI();
  applyFilters();
}

function initUI(){
  const groups = ['all', ...new Set(rawTargets.map(t => t.source_group || 'other'))];
  const types = ['all', ...new Set(rawTargets.map(t => t.type || 'other'))];
  const gf = document.getElementById('groupFilter');
  const tf = document.getElementById('typeFilter');
  gf.innerHTML = groups.map(g => `<option value="${g}">${g === 'all' ? 'الكل' : g}</option>`).join('');
  tf.innerHTML = types.map(t => `<option value="${t}">${t === 'all' ? 'الكل' : t}</option>`).join('');
  gf.value = localStorage.getItem('bouh_group') || 'all';
  tf.value = localStorage.getItem('bouh_type') || 'all';
  document.getElementById('sortFilter').value = localStorage.getItem('bouh_sort') || 'priority_desc';
  gf.addEventListener('change', ()=>{ localStorage.setItem('bouh_group', gf.value); applyFilters(); });
  tf.addEventListener('change', ()=>{ localStorage.setItem('bouh_type', tf.value); applyFilters(); });
  document.getElementById('sortFilter').addEventListener('change', ()=>{ localStorage.setItem('bouh_sort', document.getElementById('sortFilter').value); applyFilters(); });
  document.getElementById('btnExportGeoJSON').addEventListener('click', exportGeoJSON);
  document.getElementById('btnExportCSV').addEventListener('click', exportCSV);
  document.getElementById('btnExportKML').addEventListener('click', exportKML);
  document.getElementById('csvInput').addEventListener('change', importCSV);
}

function filteredTargets(){
  const group = document.getElementById('groupFilter').value;
  const type = document.getElementById('typeFilter').value;
  const sort = document.getElementById('sortFilter').value;
  let arr = rawTargets.filter(t =>
    (group === 'all' || (t.source_group || 'other') === group) &&
    (type === 'all' || (t.type || 'other') === type)
  );
  arr.sort((a,b)=>{
    if(sort === 'priority_desc') return (b.priority||0)-(a.priority||0);
    if(sort === 'priority_asc') return (a.priority||0)-(b.priority||0);
    if(sort === 'lat_asc') return (a.lat||0)-(b.lat||0);
    if(sort === 'lng_asc') return (a.lng||0)-(b.lng||0);
    return 0;
  });
  return arr;
}

function applyFilters(){
  const arr = filteredTargets();
  renderSummary(arr);
  renderList(arr);
  renderMap(arr);
  if (!selectedId || !arr.some(t => String(t.id) === String(selectedId))){
    selectedId = arr[0]?.id || null;
  }
  renderDetail(arr.find(t => String(t.id) === String(selectedId)) || arr[0] || null);
}

function renderSummary(arr){
  const total = rawTargets.length;
  const displayed = arr.length;
  const top = [...rawTargets].sort((a,b)=> (b.priority||0)-(a.priority||0))[0];
  const counts = rawTargets.reduce((acc, t) => { acc[t.source_group || 'other'] = (acc[t.source_group || 'other'] || 0) + 1; return acc; }, {});
  const summary = [
    ['الأهداف', `${total}`, 'كل السجلات المدمجة'],
    ['المعروض الآن', `${displayed}`, 'بعد الفلترة'],
    ['أعلى أولوية', top ? top.name : '—', top ? `${fmt(top.priority,3)}` : ''],
    ['المجموعات', Object.keys(counts).length, 'core / review / archive / reference']
  ];
  const html = summary.map(([k,v,s]) => `
    <div class="card">
      <div class="k">${k}</div>
      <div class="v">${v}</div>
      <div class="s">${s}</div>
    </div>
  `).join('');
  document.getElementById('summaryCards').innerHTML = html;
}

function badgeLabel(group){
  const labels = {
    core: 'Core', review: 'Review', archive: 'Archive', reference: 'Reference', derived: 'Derived', source: 'Source'
  };
  return labels[group] || group || 'Other';
}

function renderList(arr){
  const el = document.getElementById('targetList');
  el.innerHTML = arr.map(t => `
    <div class="target-row ${String(t.id)===String(selectedId) ? 'active':''}" data-id="${t.id}">
      <div class="target-top">
        <div class="target-name">${t.name}</div>
        <div class="badge ${t.source_group || 'other'}">${badgeLabel(t.source_group)}</div>
      </div>
      <div class="target-meta">
        <div>${t.belt || ''} • ${t.type || ''}</div>
        <div>${fmt(t.lat)} , ${fmt(t.lng)}</div>
        <div>Priority: ${Number(t.priority || 0).toFixed(3)} • Score: ${Number(t.score || 0).toFixed(3)}</div>
      </div>
    </div>
  `).join('');
  el.querySelectorAll('.target-row').forEach(node => {
    node.addEventListener('click', () => {
      selectedId = node.dataset.id;
      renderList(arr);
      renderDetail(arr.find(t => String(t.id)===String(selectedId)));
    });
  });
}

function boundsForAll(arr){
  const all = [...arr, ...rawEnvelopes];
  let west=Infinity,east=-Infinity,south=Infinity,north=-Infinity;
  for(const t of arr){
    west=Math.min(west, Number(t.lng)); east=Math.max(east, Number(t.lng));
    south=Math.min(south, Number(t.lat)); north=Math.max(north, Number(t.lat));
  }
  for(const e of rawEnvelopes){
    const b = e.bounds;
    west=Math.min(west, b.west); east=Math.max(east, b.east);
    south=Math.min(south, b.south); north=Math.max(north, b.north);
  }
  const padLng = (east-west)*0.08 || 0.03;
  const padLat = (north-south)*0.08 || 0.03;
  return {west: west-padLng, east: east+padLng, south: south-padLat, north: north+padLat};
}

function project(lon, lat, b, W=1080, H=650){
  const x = 70 + ((lon - b.west) / (b.east - b.west)) * W;
  const y = 40 + (1 - (lat - b.south) / (b.north - b.south)) * H;
  return [x,y];
}

function renderMap(arr){
  const svg = document.getElementById('mapSvg');
  const W=1080, H=650;
  const b = boundsForAll(arr);
  const parts = [];
  // background grid
  parts.push(`<rect x="0" y="0" width="1200" height="760" fill="url(#bg)"/>`);
  parts.push(`<defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#f8fafc"/>
      <stop offset="45%" stop-color="#ecfeff"/>
      <stop offset="100%" stop-color="#dbeafe"/>
    </linearGradient>
  </defs>`);
  // axes titles
  parts.push(`<text x="600" y="28" text-anchor="middle" class="svg-title">BOUH MASTER PACKAGE - Operational Envelope</text>`);
  parts.push(`<text x="600" y="48" text-anchor="middle" class="svg-small">Regional scene baseline + derived envelopes + targets</text>`);
  // grid lines
  for(let i=0;i<=8;i++){
    const x = 70 + i*(W/8);
    parts.push(`<line x1="${x}" y1="40" x2="${x}" y2="${40+H}" stroke="#94a3b8" stroke-opacity=".15"/>`);
  }
  for(let i=0;i<=6;i++){
    const y = 40 + i*(H/6);
    parts.push(`<line x1="70" y1="${y}" x2="${70+W}" y2="${y}" stroke="#94a3b8" stroke-opacity=".15"/>`);
  }
  // scene + envelopes
  const toPath = ring => ring.map((c,idx)=> {
    const [x,y]=project(c[0], c[1], b, W, H);
    return `${idx===0?'M':'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join(' ') + ' Z';
  for(const e of rawEnvelopes){
    const path = toPath(e.ring);
    const col = e.type === 'scene_baseline' ? '#0ea5e9' : '#f59e0b';
    const alpha = e.type === 'scene_baseline' ? '.18' : '.10';
    parts.push(`<path d="${path}" fill="${col}" fill-opacity="${alpha}" stroke="${col}" stroke-width="2.5" stroke-dasharray="${e.type === 'scene_baseline' ? '8 6' : '4 5'}"/>`);
    const bb = e.bounds;
    const [x,y] = project((bb.west+bb.east)/2, bb.north, b, W, H);
    parts.push(`<text x="${x.toFixed(1)}" y="${(y-5).toFixed(1)}" class="svg-small" text-anchor="middle">${e.name}</text>`);
  }
  // points
  for(const t of arr){
    const [x,y] = project(t.lng, t.lat, b, W, H);
    const col = colorMap[t.source_group] || '#64748b';
    const r = t.id === selectedId ? 9 : 7;
    parts.push(`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${r}" fill="${col}" stroke="#0f172a" stroke-width="2" data-id="${t.id}"/>`);
    if(t.priority >= 50 || t.id === selectedId || t.id === 'tb' || t.id === 'th' || t.id === 'ta' || t.id === 'tg' || t.id === 'ref1' || String(t.id).startsWith('rr') || String(t.id).startsWith('rp')){
      parts.push(`<text x="${(x+10).toFixed(1)}" y="${(y-10).toFixed(1)}" class="svg-label">${t.name}</text>`);
    }
  }
  // legend inset
  parts.push(`<rect x="78" y="${(H+65)}" width="260" height="58" rx="12" fill="rgba(255,255,255,.82)" stroke="rgba(15,23,42,.12)"/>`);
  parts.push(`<text x="90" y="${(H+86)}" class="svg-small">النطاق الإقليمي: ${b.west.toFixed(3)}E - ${b.east.toFixed(3)}E | ${b.south.toFixed(3)}N - ${b.north.toFixed(3)}N</text>`);
  parts.push(`<text x="90" y="${(H+104)}" class="svg-small">الأهداف تُعرض حسب الفلترة الحالية مع الأغلفة المشتقة</text>`);
  svg.innerHTML = parts.join('\n');
  svg.querySelectorAll('circle[data-id]').forEach(node => {
    node.addEventListener('click', () => {
      selectedId = node.dataset.id;
      applyFilters();
    });
  });
}

function renderDetail(t){
  const el = document.getElementById('targetDetail');
  if(!t){
    el.innerHTML = '<p>لا يوجد هدف معروض حالياً.</p>';
    return;
  }
  const badge = badgeLabel(t.source_group);
  el.innerHTML = `
    <h3>${t.name} <span class="badge ${t.source_group || 'other'}">${badge}</span></h3>
    <p><b>ID:</b> ${t.id}</p>
    <p><b>Belt:</b> ${t.belt || ''}</p>
    <p><b>Type:</b> ${t.type || ''}</p>
    <p><b>Coordinates:</b> ${fmt(t.lat)} , ${fmt(t.lng)}</p>
    <p><b>Priority:</b> ${Number(t.priority || 0).toFixed(3)}</p>
    <p><b>Score:</b> ${Number(t.score || 0).toFixed(3)}</p>
    <p><b>Evidence rank:</b> ${t.evidence_rank || '—'}</p>
    <p><b>Note:</b> ${t.note || ''}</p>
    <p><b>Decision:</b> ${decisionFor(t)}</p>
  `;
}

function decisionFor(t){
  const p = Number(t.priority || 0);
  if(p >= 53) return 'DRILL / GPZ NOW';
  if(p >= 43) return 'Target-B / High priority review';
  if(p >= 33) return 'HOLD / continue validation';
  return 'Recon / background';
}

function asGeoJSON(){
  const features = rawTargets.map(t => ({
    type:'Feature',
    properties:{...t},
    geometry:{type:'Point', coordinates:[Number(t.lng), Number(t.lat)]}
  })).concat(rawEnvelopes.map(e => ({
    type:'Feature',
    properties:{id:e.id, name:e.name, belt:e.belt, type:e.type, source_group:e.source_group, source:e.source, note:e.note},
    geometry:{type:'Polygon', coordinates:[e.ring]}
  })));
  return {type:'FeatureCollection', name:'BOUH_MASTER_PACKAGE', features};
}

function downloadBlob(filename, text, mime='application/octet-stream'){
  const blob = new Blob([text], {type:mime});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 1000);
}

function exportGeoJSON(){
  downloadBlob('BOUH_MASTER_PACKAGE.geojson', JSON.stringify(asGeoJSON(), null, 2), 'application/geo+json');
}

function exportCSV(){
  const headers = Object.keys(rawTargets[0]);
  const rows = [headers.join(',')].concat(rawTargets.map(t => headers.map(h => {
    const v = String(t[h] ?? '').replaceAll('"','""');
    return `"${v}"`;
  }).join(',')));
  downloadBlob('targets_master.csv', rows.join('\n'), 'text/csv;charset=utf-8');
}

function toKML(){
  const esc = s => String(s ?? '').replace(/[<>&"]/g, ch => ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[ch]));
  const styles = `
    <Style id="core"><IconStyle><color>ff00a5ff</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/wht-circle.png</href></Icon></IconStyle></Style>
    <Style id="review"><IconStyle><color>ff0000ff</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/red-circle.png</href></Icon></IconStyle></Style>
    <Style id="archive"><IconStyle><color>ffff0000</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/blu-circle.png</href></Icon></IconStyle></Style>
    <Style id="reference"><IconStyle><color>ff00ff00</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/grn-circle.png</href></Icon></IconStyle></Style>
    <Style id="derived"><IconStyle><color>ff00ffff</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/ylw-circle.png</href></Icon></IconStyle></Style>
    <Style id="source"><IconStyle><color>ffffffff</color><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/wht-circle.png</href></Icon></IconStyle></Style>
    <Style id="scene_poly"><LineStyle><color>ffff00ff</color><width>3</width></LineStyle><PolyStyle><color>2200ff00</color></PolyStyle></Style>
    <Style id="env_poly"><LineStyle><color>ff00ffff</color><width>2</width></LineStyle><PolyStyle><color>2200ffff</color></PolyStyle></Style>`;
  const pmPoint = t => `
    <Placemark>
      <name>${esc(t.name)}</name>
      <description><![CDATA[<b>ID:</b> ${esc(t.id)}<br/><b>Belt:</b> ${esc(t.belt)}<br/><b>Type:</b> ${esc(t.type)}<br/><b>Priority:</b> ${esc(t.priority)}<br/><b>Note:</b> ${esc(t.note)}]]></description>
      <styleUrl>#${esc(t.source_group || 'source')}</styleUrl>
      <Point><coordinates>${t.lng},${t.lat},0</coordinates></Point>
    </Placemark>`;
  const pmPoly = e => `
    <Placemark>
      <name>${esc(e.name)}</name>
      <description><![CDATA[<b>Belt:</b> ${esc(e.belt)}<br/><b>Note:</b> ${esc(e.note)}]]></description>
      <styleUrl>#${e.type === 'scene_baseline' ? 'scene_poly' : 'env_poly'}</styleUrl>
      <Polygon><outerBoundaryIs><LinearRing><coordinates>${e.ring.map(c => `${c[0]},${c[1]},0`).join(' ')}</coordinates></LinearRing></outerBoundaryIs></Polygon>
    </Placemark>`;
  return `<?xml version="1.0" encoding="UTF-8"?>
  <kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>BOUH_MASTER_PACKAGE</name>${styles}
    <Folder><name>Regional scene baseline</name>${rawEnvelopes.filter(e=>e.type==='scene_baseline').map(pmPoly).join('')}</Folder>
    <Folder><name>Derived envelopes</name>${rawEnvelopes.filter(e=>e.type!=='scene_baseline').map(pmPoly).join('')}</Folder>
    <Folder><name>Targets</name>${rawTargets.map(pmPoint).join('')}</Folder>
  </Document></kml>`;
}

function exportKML(){
  downloadBlob('BOUH_MASTER_PACKAGE.kml', toKML(), 'application/vnd.google-earth.kml+xml');
}

function importCSV(ev){
  const file = ev.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const text = reader.result.toString();
    const rows = text.split(/\r?\n/).filter(Boolean);
    const header = rows[0].split(',').map(s => s.replace(/^"|"$/g,''));
    const data = rows.slice(1).map(line => {
      const cells = [];
      let cur=''; let q=false;
      for(let i=0;i<line.length;i++){
        const ch = line[i];
        if(ch === '"' && line[i+1] === '"'){ cur += '"'; i++; continue; }
        if(ch === '"'){ q = !q; continue; }
        if(ch === ',' && !q){ cells.push(cur); cur=''; continue; }
        cur += ch;
      }
      cells.push(cur);
      const obj = {};
      header.forEach((h,idx)=>obj[h] = cells[idx] ?? '');
      return obj;
    });
    rawTargets = data.map(o => ({
      ...o,
      lat: Number(o.lat ?? o.Lat ?? o['Lat(N)'] ?? 0),
      lng: Number(o.lng ?? o.Lon ?? o['Lon(E)'] ?? 0),
      priority: Number(o.priority ?? o.Priority ?? 0),
      score: Number(o.score ?? o.Score ?? 0),
    }));
    localStorage.setItem('bouh_custom_csv', text);
    applyFilters();
  };
  reader.readAsText(file);
}

function bootCustomCSV(){
  const saved = localStorage.getItem('bouh_custom_csv');
  if(saved){
    const rows = saved.split(/\r?\n/).filter(Boolean);
    if(rows.length > 1){
      const header = rows[0].split(',').map(s => s.replace(/^"|"$/g,''));
      rawTargets = rows.slice(1).map(line => {
        const cells = [];
        let cur=''; let q=false;
        for(let i=0;i<line.length;i++){
          const ch = line[i];
          if(ch === '"' && line[i+1] === '"'){ cur += '"'; i++; continue; }
          if(ch === '"'){ q = !q; continue; }
          if(ch === ',' && !q){ cells.push(cur); cur=''; continue; }
          cur += ch;
        }
        cells.push(cur);
        const obj = {};
        header.forEach((h,idx)=>obj[h] = cells[idx] ?? '');
        return {
          ...obj,
          lat: Number(obj.lat ?? obj.Lat ?? obj['Lat(N)'] ?? 0),
          lng: Number(obj.lng ?? obj.Lon ?? obj['Lon(E)'] ?? 0),
          priority: Number(obj.priority ?? obj.Priority ?? 0),
          score: Number(obj.score ?? obj.Score ?? 0),
        };
      });
    }
  }
}

window.addEventListener('DOMContentLoaded', async ()=>{
  bootCustomCSV();
  await loadData();
  if(rawTargets.length === 0){
    document.getElementById('targetDetail').innerHTML = 'لا توجد بيانات.';
  }
  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('service-worker.js').catch(()=>{});
  }
});
