# BOUH Android Source Project

This project wraps the offline web app in a native Android WebView shell.

Build requirements:
- Android Studio Hedgehog or newer
- JDK 17

Build steps:
1. Open the root folder in Android Studio.
2. Allow Gradle sync.
3. Run the `app` module on a device or emulator.
4. Build a release APK from Build > Generate Signed Bundle / APK.

The Web app sources are mirrored in `app/src/main/assets/`.
