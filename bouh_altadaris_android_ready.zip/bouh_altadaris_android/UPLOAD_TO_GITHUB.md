# خطوات الرفع للحصول على رابط تثبيت APK مباشر

1. افتح مستودعك:
   https://github.com/abuaziza404-tech/gold-field-app

2. اضغط النقاط الثلاث ثم Upload files.

3. ارفع كل ملفات هذا المجلد، وليس ملف ZIP فقط.

4. اضغط Commit changes.

5. افتح Actions:
   https://github.com/abuaziza404-tech/gold-field-app/actions

6. افتح Workflow باسم:
   Build BOUH Android APK

7. اضغط Run workflow.

8. بعد ظهور علامة النجاح الخضراء، حمّل APK من Artifacts أو استخدم الرابط المباشر:

https://github.com/abuaziza404-tech/gold-field-app/releases/latest/download/bouh-altadaris.apk
