import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BouhAltadarisApp());
}

class BouhAltadarisApp extends StatelessWidget {
  const BouhAltadarisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بوح التضاريس',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB8860B),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF08110E),
      ),
      home: const HomeScreen(),
    );
  }
}

class Target {
  final String id;
  final String name;
  final double lat;
  final double lon;
  final String type;
  final String belt;
  final double structure;
  final double pattern;
  final double alteration;
  final double carrier;
  final double cluster;
  final double terrain;
  final double context;
  final double clay;
  final double iron;
  final double silica;
  final double twi;

  Target({
    required this.id,
    required this.name,
    required this.lat,
    required this.lon,
    required this.type,
    required this.belt,
    required this.structure,
    required this.pattern,
    required this.alteration,
    required this.carrier,
    required this.cluster,
    required this.terrain,
    required this.context,
    required this.clay,
    required this.iron,
    required this.silica,
    required this.twi,
  });

  factory Target.fromJson(Map<String, dynamic> j) => Target(
        id: j['id'],
        name: j['name'],
        lat: (j['lat'] as num).toDouble(),
        lon: (j['lon'] as num).toDouble(),
        type: j['type'],
        belt: j['belt'],
        structure: (j['structure'] as num).toDouble(),
        pattern: (j['pattern'] as num).toDouble(),
        alteration: (j['alteration'] as num).toDouble(),
        carrier: (j['carrier'] as num).toDouble(),
        cluster: (j['cluster'] as num).toDouble(),
        terrain: (j['terrain'] as num).toDouble(),
        context: (j['context'] as num).toDouble(),
        clay: (j['clay'] as num).toDouble(),
        iron: (j['iron'] as num).toDouble(),
        silica: (j['silica'] as num).toDouble(),
        twi: (j['twi'] as num).toDouble(),
      );
}

class BouhEngine {
  static double hScore(Target t) {
    return (0.30 * t.structure) +
        (0.20 * t.pattern) +
        (0.15 * t.alteration) +
        (0.10 * t.carrier) +
        (0.10 * t.cluster) +
        (0.10 * t.terrain) +
        (0.05 * t.context);
  }

  static double pScore(Target t) {
    final spectral = ((t.clay / 1.20).clamp(0.0, 1.0) +
            (t.iron / 1.35).clamp(0.0, 1.0) +
            (t.silica / 1.05).clamp(0.0, 1.0)) /
        3.0;
    final geochemProxy = 0.62; // placeholder until assay/QA-QC is available.
    final regional = t.context;
    return (0.36 * t.structure) +
        (0.28 * spectral) +
        (0.16 * geochemProxy) +
        (0.12 * t.terrain) +
        (0.08 * regional);
  }

  static List<String> killFails(Target t) {
    final fails = <String>[];
    if (t.structure < 0.70) fails.add('L2 Structure/Lineament weak');
    if (t.clay < 1.082) fails.add('L3 Clay/SWIR below calibration');
    if (t.iron < 1.152) fails.add('L4 Iron below calibration');
    if (t.silica < 0.947) fails.add('L5 Silica below calibration');
    if (t.cluster < 0.60) fails.add('L8 Cluster weak');
    if (t.twi < 9.35 && t.type.contains('Placer')) fails.add('L10 TWI weak for placer');
    if (pScore(t) < 0.642) fails.add('L18 Composite P reject');
    return fails;
  }

  static String decision(Target t) {
    final fails = killFails(t);
    final h = hScore(t);
    final p = pScore(t);
    if (fails.isNotEmpty) return 'HOLD / FIELD CHECK';
    if (h >= 0.80 && p >= 0.78) return 'TARGET-B ELITE';
    if (h >= 0.70) return 'HIGH PRIORITY';
    if (h >= 0.55) return 'TEST';
    return 'REJECT';
  }

  static String fieldInstruction(Target t) {
    if (t.type.contains('Placer')) {
      return 'افحص الانحناء الداخلي للوادي، شقوق bedrock، والرمال السوداء تحت الحصى. GPZ: High Yield / Difficult عند الصخور الثقيلة.';
    }
    if (t.type.contains('Gossan')) {
      return 'نفذ pit قصير فوق الجوسان ثم عيّن vein + wall rock. ابحث عن boxwork وsulfides مؤكسدة.';
    }
    return 'الخندق عمودي على strike. ابدأ من contact بين quartz/host، وخذ عينات من vein + wall rock + iron zone.';
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Target>> targetsFuture;
  int page = 0;

  @override
  void initState() {
    super.initState();
    targetsFuture = loadTargets();
  }

  Future<List<Target>> loadTargets() async {
    final raw = await rootBundle.loadString('assets/targets.json');
    final data = jsonDecode(raw) as List<dynamic>;
    final targets = data.map((e) => Target.fromJson(e)).toList();
    targets.sort((a, b) => BouhEngine.hScore(b).compareTo(BouhEngine.hScore(a)));
    return targets;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('بوح التضاريس'),
          centerTitle: true,
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: page,
          onDestinationSelected: (i) => setState(() => page = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.radar), label: 'الأهداف'),
            NavigationDestination(icon: Icon(Icons.auto_graph), label: 'تحليل'),
            NavigationDestination(icon: Icon(Icons.assignment), label: 'الميدان'),
            NavigationDestination(icon: Icon(Icons.info), label: 'النظام'),
          ],
        ),
        body: FutureBuilder<List<Target>>(
          future: targetsFuture,
          builder: (context, snapshot) {
            if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
            final targets = snapshot.data!;
            return switch (page) {
              0 => TargetsPage(targets: targets),
              1 => AnalyzePage(targets: targets),
              2 => const FieldPage(),
              _ => const ManifestPage(),
            };
          },
        ),
      ),
    );
  }
}

class TargetsPage extends StatelessWidget {
  final List<Target> targets;
  const TargetsPage({super.key, required this.targets});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: targets.length,
      itemBuilder: (context, i) {
        final t = targets[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            title: Text('${t.name} — ${BouhEngine.decision(t)}'),
            subtitle: Text(
              '${t.id}\n${t.lat.toStringAsFixed(4)}, ${t.lon.toStringAsFixed(4)}\n'
              'H=${BouhEngine.hScore(t).toStringAsFixed(3)} | P=${BouhEngine.pScore(t).toStringAsFixed(3)} | ${t.belt}',
            ),
            isThreeLine: true,
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => TargetDetailPage(target: t)),
            ),
          ),
        );
      },
    );
  }
}

class TargetDetailPage extends StatelessWidget {
  final Target target;
  const TargetDetailPage({super.key, required this.target});

  @override
  Widget build(BuildContext context) {
    final fails = BouhEngine.killFails(target);
    final maps = 'https://www.google.com/maps/search/?api=1&query=${target.lat},${target.lon}';
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(target.name)),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _metric('القرار', BouhEngine.decision(target)),
            _metric('H-Score', BouhEngine.hScore(target).toStringAsFixed(3)),
            _metric('P-Score', BouhEngine.pScore(target).toStringAsFixed(3)),
            _metric('النوع', target.type),
            _metric('الحزام', target.belt),
            _metric('الإحداثيات', '${target.lat}, ${target.lon}'),
            _metric('رابط Google Maps', maps),
            const SizedBox(height: 12),
            const Text('L1–L18 Kill Check', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(fails.isEmpty ? '0 FAIL ✅' : fails.join('\n')),
            const SizedBox(height: 12),
            const Text('تعليمات ميدانية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(BouhEngine.fieldInstruction(target)),
            const SizedBox(height: 12),
            const Text('قاعدة الثقة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Text('هذا تصنيف احتمالي. قرار الحفر النهائي يتطلب Field Validation + Assay + QA/QC.'),
          ],
        ),
      ),
    );
  }

  Widget _metric(String a, String b) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(a, style: const TextStyle(color: Colors.amber)),
              const SizedBox(height: 4),
              Text(b),
            ],
          ),
        ),
      );
}

class AnalyzePage extends StatefulWidget {
  final List<Target> targets;
  const AnalyzePage({super.key, required this.targets});

  @override
  State<AnalyzePage> createState() => _AnalyzePageState();
}

class _AnalyzePageState extends State<AnalyzePage> {
  final latCtrl = TextEditingController(text: '20.88');
  final lonCtrl = TextEditingController(text: '36.06');
  bool structure = true;
  bool quartz = true;
  bool iron = true;
  bool sulfide = false;
  bool gossan = false;

  @override
  Widget build(BuildContext context) {
    final score = [structure, quartz, iron, sulfide, gossan].where((x) => x).length / 5.0;
    final decision = !structure
        ? 'REJECT: لا توجد بنية'
        : (structure && quartz && iron && sulfide)
            ? 'DIG / DRILL CANDIDATE'
            : (structure && quartz && iron)
                ? 'TEST / TRENCH'
                : 'HOLD / SAMPLE ONLY';
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('تحليل نقطة جديدة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        TextField(controller: latCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Latitude')),
        TextField(controller: lonCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Longitude')),
        SwitchListTile(value: structure, onChanged: (v) => setState(() => structure = v), title: const Text('Structure / Shear')),
        SwitchListTile(value: quartz, onChanged: (v) => setState(() => quartz = v), title: const Text('Quartz / Silica')),
        SwitchListTile(value: iron, onChanged: (v) => setState(() => iron = v), title: const Text('Iron Oxide / Gossan color')),
        SwitchListTile(value: sulfide, onChanged: (v) => setState(() => sulfide = v), title: const Text('Sulfide observed')),
        SwitchListTile(value: gossan, onChanged: (v) => setState(() => gossan = v), title: const Text('Gossan / Boxwork')),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Decision: $decision', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text('Field confidence proxy: ${(score * 100).toStringAsFixed(0)}%'),
              Text('Google Maps: https://www.google.com/maps/search/?api=1&query=${latCtrl.text},${lonCtrl.text}'),
            ]),
          ),
        ),
      ],
    );
  }
}

class FieldPage extends StatelessWidget {
  const FieldPage({super.key});
  @override
  Widget build(BuildContext context) {
    const items = [
      'تأكد من GPS والخريطة offline.',
      'ابدأ بالبنية: shear/fault/intersection.',
      'لا تعتمد على اللون أو الكوارتز وحده.',
      'خذ عينات vein + wall rock + iron zone.',
      'الخندق عمودي على اتجاه العرق أو shear.',
      'أوقف العمل إذا لا توجد بنية أو تحوير أو quartz متشقق.',
      'الحفر النهائي يتطلب Assay + QA/QC.'
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('النظام الميداني التنفيذي', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ...items.map((e) => Card(child: ListTile(leading: const Icon(Icons.check_circle), title: Text(e)))),
      ],
    );
  }
}

class ManifestPage extends StatelessWidget {
  const ManifestPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        Text('BOUH_MANIFEST', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        SizedBox(height: 12),
        Text('Structure controls → Pattern refines → Alteration supports → Carrier proves → Geochem upgrades → Risk constrains → Logistics enables → DTX tracks → Document formalizes → Business captures value.'),
        SizedBox(height: 16),
        Text('الأنظمة المدمجة:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text('1. BOUH SUPREME ENGINE\n2. iGold v8.0 Layer\n3. Target-B System\n4. Field Execution\n5. AI–Geology Integration\n6. GeoChem QA/QC\n7. Risk Engine\n8. Logistics Engine\n9. Digital Twin Exploration\n10. Institutional / Business Output'),
        SizedBox(height: 16),
        Text('تنبيه:', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.amber)),
        Text('التطبيق أداة ترجيح واستهداف. لا يعطي إثباتًا اقتصاديًا قبل العينات والتحاليل المختبرية وسلسلة QA/QC.'),
      ],
    );
  }
}
