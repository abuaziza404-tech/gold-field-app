# بوح التضاريس — BOUH Altadaris Android

تطبيق Android/Flutter مدمج بمنطق BOUH_MANIFEST:

- BOUH SUPREME ENGINE
- iGold v8.0 Calibration Layer
- Target-B ranking
- L1-L18 kill check
- Field execution protocol
- GPS coordinate output via Google Maps link
- Arabic UI

## Direct APK URL after GitHub Actions build

After uploading this repository to:

`abuaziza404-tech/gold-field-app`

and running Actions, the direct APK link will be:

https://github.com/abuaziza404-tech/gold-field-app/releases/latest/download/bouh-altadaris.apk

## Build locally

```bash
flutter pub get
flutter build apk --release
```

APK output:

```bash
build/app/outputs/flutter-apk/app-release.apk
```

## Important

This app is a decision-support tool. Field validation, assays, and QA/QC are required before any economic or drilling decision.
